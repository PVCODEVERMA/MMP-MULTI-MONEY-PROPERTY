mkdir logs
echo "# Application Logs Directory" 